# FHI-aims
Install the modified FHI-aims, which can output Hamiltonian matrices, overlap matrices and position matrices.
