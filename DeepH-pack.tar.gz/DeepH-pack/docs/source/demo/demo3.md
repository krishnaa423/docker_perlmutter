# Demo: Train the DeepH model using the ABACUS interface
Train the DeepH model by random graphene supercells
and predict the Hamiltonian of carbon nanotube using
the ABACUS interface. See README.md in
[this file](https://github.com/deepmodeling/DeepH-pack/files/9526304/demo_abacus.zip)
for details.

