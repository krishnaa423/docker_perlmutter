# HPRO package

HPRO is a python module for Hamiltonian Projection and Reconstruction to atomic Orbitals.

Author: Xiaoxun Gong (xiaoxun.gong@berkeley.edu)

## Installation guide

1. You should have Python 3.8+ for installing this package.
2. Go to `src/` directory and use the command `pip install .` to install the package.

